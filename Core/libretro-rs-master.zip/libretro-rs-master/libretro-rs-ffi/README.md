# libretro-rs-sys

Raw API bindings for `libretro.h`, minus the forward declarations for functions.
