#ifndef _BUFIO_H
#define _BUFIO_H

#include "bufio.fdh"

#endif
