
extern signed int sin_table[256];
