
#ifndef _INTRO_H
#define _INTRO_H


bool intro_init(int param);
void intro_tick();

#endif
