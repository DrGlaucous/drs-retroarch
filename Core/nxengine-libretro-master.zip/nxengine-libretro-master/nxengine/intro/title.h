
#ifndef _TITLE_H
#define _TITLE_H


bool title_init(int param);
void title_tick();

#endif
