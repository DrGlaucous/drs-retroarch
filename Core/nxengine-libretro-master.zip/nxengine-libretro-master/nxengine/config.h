
#ifndef _CONFIG_H
#define _CONFIG_H

// include the Doukutsu data-file extractor in the build
// (it's needed only the first time the program is run).
#define CONFIG_DATA_EXTRACTOR

#endif
