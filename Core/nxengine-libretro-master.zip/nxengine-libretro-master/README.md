nxengine-libretro
=================

Port of NxEngine to the libretro API. NXEngine is a Cave Story game engine clone.

Requires Cave Story 1.0.0.6 and the Aeon Genesis translation.

Cave Story is available from Studio Pixel's website:
http://studiopixel.sakura.ne.jp/archives/index.html

The Aeon Genesis translation is available from:
http://agtp.romhack.net/project.php?id=cavestory
