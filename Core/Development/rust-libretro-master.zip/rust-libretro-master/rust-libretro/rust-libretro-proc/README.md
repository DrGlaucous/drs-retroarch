rust-libretro-proc
==================

Procedural macros for [rust-libretro](../).

[![Build status](https://img.shields.io/github/actions/workflow/status/max-m/rust-libretro/main.yaml?branch=master)](https://github.com/max-m/rust-libretro/actions)
[![Latest version](https://img.shields.io/crates/v/rust-libretro-proc.svg)](https://crates.io/crates/rust-libretro-proc)
[![Documentation](https://docs.rs/rust-libretro-proc/badge.svg)](https://docs.rs/rust-libretro-proc)
![License](https://img.shields.io/crates/l/rust-libretro-proc.svg)
