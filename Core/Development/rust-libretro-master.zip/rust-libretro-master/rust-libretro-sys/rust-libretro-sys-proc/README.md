rust-libretro-sys-proc
======================

Procedural macros for [rust-libretro-sys](../).

[![Build status](https://img.shields.io/github/actions/workflow/status/max-m/rust-libretro/main.yaml?branch=master)](https://github.com/max-m/rust-libretro/actions)
[![Latest version](https://img.shields.io/crates/v/rust-libretro-sys-proc.svg)](https://crates.io/crates/rust-libretro-sys-proc)
[![Documentation](https://docs.rs/rust-libretro-sys-proc/badge.svg)](https://docs.rs/rust-libretro-sys-proc)
![License](https://img.shields.io/crates/l/rust-libretro-sys-proc.svg)
