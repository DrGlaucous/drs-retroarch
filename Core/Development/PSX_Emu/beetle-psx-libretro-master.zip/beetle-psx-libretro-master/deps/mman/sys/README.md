mman-win32
==========

mman library for Windows. mirror of https://code.google.com/p/mman-win32/

A light implementation of the mmap functions for MinGW.

The mmap-win32 library implements a wrapper for mmap functions around the memory mapping Windows API.

License: MIT License
