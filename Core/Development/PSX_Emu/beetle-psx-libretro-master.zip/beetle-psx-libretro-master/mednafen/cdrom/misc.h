#ifndef __MDFN_CDROM_MISC_H
#define __MDFN_CDROM_MISC_H

void MDFN_strtoupper(std::string &str);
void MDFN_strtoupper(char *str);

#endif
