#ifndef __MDFN_PSX_DIS_H
#define __MDFN_PSX_DIS_H

std::string DisassembleMIPS(uint32 PC, uint32 instr);

#endif
