#ifndef __MDFN_PSX_INPUT_NEGCON_H
#define __MDFN_PSX_INPUT_NEGCON_H

InputDevice *Device_neGcon_Create(void);
extern InputDeviceInputInfoStruct Device_neGcon_IDII[21];

#endif
