#ifndef __MDFN_PSX_INPUT_JUSTIFIER_H
#define __MDFN_PSX_INPUT_JUSTIFIER_H

InputDevice *Device_Justifier_Create(void);
extern InputDeviceInputInfoStruct Device_Justifier_IDII[6];

#endif
