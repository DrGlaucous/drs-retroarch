#ifndef __MDFN_PSX_INPUT_MOUSE_H
#define __MDFN_PSX_INPUT_MOUSE_H

InputDevice *Device_Mouse_Create(void);
extern InputDeviceInputInfoStruct Device_Mouse_IDII[4];

#endif
