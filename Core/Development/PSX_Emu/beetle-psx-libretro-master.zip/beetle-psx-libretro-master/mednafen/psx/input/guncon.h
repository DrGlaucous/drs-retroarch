#ifndef __MDFN_PSX_INPUT_GUNCON_H
#define __MDFN_PSX_INPUT_GUNCON_H

InputDevice *Device_GunCon_Create(void);
extern InputDeviceInputInfoStruct Device_GunCon_IDII[6];

#endif
