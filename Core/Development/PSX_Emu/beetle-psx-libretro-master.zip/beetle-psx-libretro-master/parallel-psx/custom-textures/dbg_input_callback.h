#ifndef DBG_INPUT_CALLBACK_H
#define DBG_INPUT_CALLBACK_H

#include "libretro.h"
extern retro_input_state_t dbg_input_state_cb;

#endif