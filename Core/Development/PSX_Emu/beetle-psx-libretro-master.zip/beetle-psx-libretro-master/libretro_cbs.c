#include "libretro.h"

retro_video_refresh_t video_cb = NULL;
retro_environment_t environ_cb = NULL;
