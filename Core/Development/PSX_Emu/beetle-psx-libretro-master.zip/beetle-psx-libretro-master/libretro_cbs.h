#ifndef __LIBRETRO_CBS_H
#define __LIBRETRO_CBS_H

#include "libretro.h"

#ifdef __cplusplus
extern "C" {
#endif

extern retro_video_refresh_t video_cb;
extern retro_environment_t environ_cb;

#ifdef __cplusplus
}
#endif

#endif
