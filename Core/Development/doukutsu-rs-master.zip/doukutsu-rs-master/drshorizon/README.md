Experimental.

ld script and .specs taken from devkitPro
