pub struct RemotePlayerList {}

impl RemotePlayerList {
    pub fn new() -> RemotePlayerList {
        RemotePlayerList {}
    }
}
